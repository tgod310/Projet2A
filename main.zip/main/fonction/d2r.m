function [ rad ] = d2r( deg )
% permet de passer d'un angle en de gré à un angle
% en radian

rad=deg*(pi/180);

end

